/* ==========================================================================
   LOGIN — envía el formulario de inicio de sesión al backend
   ========================================================================== */
(function () {
  "use strict";

  var form = document.getElementById("login-form");
  if (!form) return;

  var status = document.getElementById("login-status");
  var auth = window.CasaCarambolaAuth;

  // si ya hay sesión, redirige directo
  var yaUser = auth.getUser();
  if (yaUser) {
    window.location.href = yaUser.role === "admin" ? "admin.html" : "index.html";
    return;
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var data = Object.fromEntries(new FormData(form).entries());

    status.textContent = "Ingresando…";
    status.style.color = "var(--brass-2)";

    fetch(auth.API_URL + "/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    })
      .then(function (res) {
        return res.json().then(function (body) {
          if (!res.ok) throw new Error(body.error || "No se pudo iniciar sesión.");
          return body;
        });
      })
      .then(function (body) {
        auth.setSession(body.token, body.user);
        status.textContent = "¡Bienvenido! Redirigiendo…";
        status.style.color = "var(--ball-6)";
        window.location.href = body.user.role === "admin" ? "admin.html" : "index.html";
      })
      .catch(function (err) {
        status.textContent = err.message;
        status.style.color = "var(--ball-3)";
      });
  });
})();
