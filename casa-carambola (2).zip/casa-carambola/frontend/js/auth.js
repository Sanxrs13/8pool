/* ==========================================================================
   AUTH — sesión de usuario/admin compartida por todas las páginas
   ========================================================================== */
(function () {
  "use strict";

  var API_URL = "http://localhost:3000/api";
  var STORAGE_TOKEN = "cc_token";
  var STORAGE_USER = "cc_user";

  function getToken() {
    return localStorage.getItem(STORAGE_TOKEN);
  }

  function getUser() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_USER) || "null");
    } catch (e) {
      return null;
    }
  }

  function setSession(token, user) {
    localStorage.setItem(STORAGE_TOKEN, token);
    localStorage.setItem(STORAGE_USER, JSON.stringify(user));
  }

  function clearSession() {
    localStorage.removeItem(STORAGE_TOKEN);
    localStorage.removeItem(STORAGE_USER);
  }

  function logout() {
    clearSession();
    window.location.href = "index.html";
  }

  function authHeaders() {
    var token = getToken();
    return token ? { Authorization: "Bearer " + token } : {};
  }

  // Pinta el estado de sesión en el nav (login / mi cuenta / admin / salir)
  function renderNavAuth() {
    var slot = document.getElementById("nav-auth");
    if (!slot) return;

    var user = getUser();
    slot.innerHTML = "";

    var nav = document.querySelector(".nav");

    if (!user) {
      var loginLink = document.createElement("a");
      loginLink.href = "login.html";
      loginLink.textContent = "Ingresar";
      slot.appendChild(loginLink);
      return;
    }

    if (user.role === "admin") {
      var adminLink = document.createElement("a");
      adminLink.href = "admin.html";
      adminLink.textContent = "Panel admin";
      slot.appendChild(adminLink);
    } else {
      var who = document.createElement("span");
      who.className = "nav-user";
      who.textContent = "Hola, " + user.nombre.split(" ")[0];
      slot.appendChild(who);
    }

    var logoutLink = document.createElement("a");
    logoutLink.href = "#";
    logoutLink.textContent = "Salir";
    logoutLink.addEventListener("click", function (e) {
      e.preventDefault();
      logout();
    });
    slot.appendChild(logoutLink);

    // cierra el menú móvil si estaba abierto al navegar por estos enlaces nuevos
    if (nav) {
      slot.querySelectorAll("a").forEach(function (a) {
        a.addEventListener("click", function () {
          nav.classList.remove("is-open");
        });
      });
    }
  }

  // Protege páginas: si no hay sesión de admin, redirige
  function requireAdminOrRedirect() {
    var user = getUser();
    var token = getToken();
    if (!user || !token || user.role !== "admin") {
      window.location.href = "login.html";
      return false;
    }
    return true;
  }

  window.CasaCarambolaAuth = {
    API_URL: API_URL,
    getToken: getToken,
    getUser: getUser,
    setSession: setSession,
    clearSession: clearSession,
    logout: logout,
    authHeaders: authHeaders,
    requireAdminOrRedirect: requireAdminOrRedirect,
  };

  // El script se carga al final del <body>, así que el DOM ya está listo:
  // no hace falta esperar al evento DOMContentLoaded (que ya habría ocurrido).
  renderNavAuth();
})();
