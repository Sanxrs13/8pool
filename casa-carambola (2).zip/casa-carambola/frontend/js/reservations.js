/* ==========================================================================
   RESERVATIONS — envia el formulario de reserva al backend
   ========================================================================== */
(function () {
  "use strict";

  // Cambia esto si tu backend corre en otro host/puerto
  var API_URL = "http://localhost:3000/api/reservas";

  var form = document.getElementById("reserve-form");
  if (!form) return;

  var status = document.getElementById("reserve-status");

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    var data = Object.fromEntries(new FormData(form).entries());
    status.textContent = "Enviando reserva…";
    status.style.color = "var(--brass-2)";

    fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    })
      .then(function (res) {
        if (!res.ok) throw new Error("No se pudo guardar la reserva");
        status.textContent = "¡Listo! Te confirmamos por teléfono antes de tu turno.";
        status.style.color = "var(--ball-6)";
        form.reset();
        if (window.casaCarambolaSound) window.casaCarambolaSound.playClack(1.2);
      })
      .catch(function () {
        status.textContent = "Hubo un problema al enviar tu reserva. Intenta de nuevo o llámanos.";
        status.style.color = "var(--ball-3)";
      });
  });
})();
