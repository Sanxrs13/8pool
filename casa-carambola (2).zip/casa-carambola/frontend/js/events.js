/* ==========================================================================
   EVENTS — carga los eventos publicados por el admin en torneos.html
   ========================================================================== */
(function () {
  "use strict";

  var contenedor = document.getElementById("eventos-publicos");
  if (!contenedor) return;

  var API_URL = (window.CasaCarambolaAuth && window.CasaCarambolaAuth.API_URL) || "http://localhost:3000/api";

  function escapeHtml(str) {
    if (str == null) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  fetch(API_URL + "/eventos")
    .then(function (res) {
      if (!res.ok) throw new Error("No se pudieron cargar los eventos");
      return res.json();
    })
    .then(function (eventos) {
      // Si el admin todavía no ha creado eventos, se deja el contenido estático de respaldo.
      if (!Array.isArray(eventos) || eventos.length === 0) return;

      contenedor.innerHTML = "";
      eventos.forEach(function (ev) {
        var card = document.createElement("div");
        card.className = "event-card";
        card.innerHTML =
          '<span class="event-date">' + escapeHtml(ev.etiqueta || ev.fecha) + "</span>" +
          "<h3>" + escapeHtml(ev.titulo) + "</h3>" +
          "<p>" + escapeHtml(ev.descripcion) + "</p>";
        contenedor.appendChild(card);
      });
    })
    .catch(function () {
      // Sin conexión al backend: se conserva el contenido estático ya presente en el HTML.
    });
})();
