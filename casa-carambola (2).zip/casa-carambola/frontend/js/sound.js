/* ==========================================================================
   SOUND — "clac" de bolas de billar sintetizado con Web Audio API
   No usa archivos de audio: genera el sonido en tiempo real.
   ========================================================================== */
(function () {
  "use strict";

  var ctx = null;

  function getContext() {
    if (!ctx) {
      var AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return null;
      ctx = new AudioCtx();
    }
    if (ctx.state === "suspended") ctx.resume();
    return ctx;
  }

  // "clac" corto: impacto de ruido filtrado + tono que cae, como dos bolas al chocar
  function playClack(strength) {
    var audio = getContext();
    if (!audio) return;
    var now = audio.currentTime;
    var vol = strength || 1;

    // capa de ruido percusivo (el "golpe")
    var bufferSize = Math.floor(audio.sampleRate * 0.045);
    var buffer = audio.createBuffer(1, bufferSize, audio.sampleRate);
    var data = buffer.getChannelData(0);
    for (var i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / bufferSize, 2.5);
    }
    var noise = audio.createBufferSource();
    noise.buffer = buffer;

    var noiseFilter = audio.createBiquadFilter();
    noiseFilter.type = "bandpass";
    noiseFilter.frequency.value = 2200;
    noiseFilter.Q.value = 1.1;

    var noiseGain = audio.createGain();
    noiseGain.gain.setValueAtTime(0.32 * vol, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

    noise.connect(noiseFilter).connect(noiseGain).connect(audio.destination);

    // capa tonal (la resonancia del marfil/resina)
    var osc = audio.createOscillator();
    osc.type = "sine";
    osc.frequency.setValueAtTime(1100, now);
    osc.frequency.exponentialRampToValueAtTime(280, now + 0.08);

    var oscGain = audio.createGain();
    oscGain.gain.setValueAtTime(0.22 * vol, now);
    oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);

    osc.connect(oscGain).connect(audio.destination);

    noise.start(now);
    noise.stop(now + 0.06);
    osc.start(now);
    osc.stop(now + 0.1);
  }

  // el primer clic "despierta" el AudioContext (los navegadores lo exigen)
  function bind() {
    var interactive = document.querySelectorAll(
      "a, button, .g-item, .event-card, input[type='submit']"
    );
    interactive.forEach(function (el) {
      el.addEventListener("click", function () {
        playClack(1);
      });
    });

    // toques mas suaves al pasar el mouse por elementos grandes
    var hoverables = document.querySelectorAll(".g-item, .why-card, .stat-card");
    hoverables.forEach(function (el) {
      el.addEventListener("mouseenter", function () {
        playClack(0.4);
      });
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bind);
  } else {
    bind();
  }

  window.casaCarambolaSound = { playClack: playClack };
})();
