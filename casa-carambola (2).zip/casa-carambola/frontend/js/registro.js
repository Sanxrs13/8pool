/* ==========================================================================
   REGISTRO — envía el formulario de creación de cuenta al backend
   ========================================================================== */
(function () {
  "use strict";

  var form = document.getElementById("registro-form");
  if (!form) return;

  var status = document.getElementById("registro-status");
  var auth = window.CasaCarambolaAuth;

  var yaUser = auth.getUser();
  if (yaUser) {
    window.location.href = yaUser.role === "admin" ? "admin.html" : "index.html";
    return;
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var data = Object.fromEntries(new FormData(form).entries());

    status.textContent = "Creando tu cuenta…";
    status.style.color = "var(--brass-2)";

    fetch(auth.API_URL + "/auth/registro", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    })
      .then(function (res) {
        return res.json().then(function (body) {
          if (!res.ok) throw new Error(body.error || "No se pudo crear la cuenta.");
          return body;
        });
      })
      .then(function (body) {
        auth.setSession(body.token, body.user);
        status.textContent = "¡Cuenta creada! Redirigiendo…";
        status.style.color = "var(--ball-6)";
        window.location.href = "index.html";
      })
      .catch(function (err) {
        status.textContent = err.message;
        status.style.color = "var(--ball-3)";
      });
  });
})();
