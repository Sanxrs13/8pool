/* ==========================================================================
   REVEAL — aparicion suave de secciones al hacer scroll
   ========================================================================== */
(function () {
  "use strict";

  var targets = document.querySelectorAll(
    ".section, .footer, .event-card, .why-card, .stat-card, .g-item"
  );
  targets.forEach(function (el) {
    el.classList.add("reveal");
  });

  if (!("IntersectionObserver" in window)) {
    targets.forEach(function (el) { el.classList.add("is-visible"); });
    return;
  }

  var io = new IntersectionObserver(
    function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          io.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12 }
  );

  targets.forEach(function (el) { io.observe(el); });
})();
