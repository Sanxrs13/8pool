/* ==========================================================================
   ADMIN — panel de administración (reservas, usuarios, eventos)
   ========================================================================== */
(function () {
  "use strict";

  var auth = window.CasaCarambolaAuth;
  if (!auth || !auth.requireAdminOrRedirect()) return;

  var API = auth.API_URL;
  var user = auth.getUser();

  var tituloEl = document.getElementById("admin-titulo");
  if (tituloEl && user) tituloEl.textContent = "Hola, " + user.nombre.split(" ")[0] + ".";

  function jsonHeaders() {
    return Object.assign({ "Content-Type": "application/json" }, auth.authHeaders());
  }

  function handleAuthError(res) {
    if (res.status === 401) {
      auth.clearSession();
      window.location.href = "login.html";
      return true;
    }
    return false;
  }

  // ---------- TABS ----------
  var tabs = document.querySelectorAll(".admin-tab");
  var panels = document.querySelectorAll(".admin-panel");
  tabs.forEach(function (tab) {
    tab.addEventListener("click", function () {
      tabs.forEach(function (t) { t.classList.remove("is-active"); });
      panels.forEach(function (p) { p.classList.remove("is-active"); });
      tab.classList.add("is-active");
      document.getElementById("panel-" + tab.dataset.tab).classList.add("is-active");
    });
  });

  // ---------- RESUMEN ----------
  function cargarResumen() {
    fetch(API + "/admin/resumen", { headers: auth.authHeaders() })
      .then(function (res) {
        if (handleAuthError(res)) return null;
        return res.json();
      })
      .then(function (data) {
        if (!data) return;
        document.getElementById("stat-usuarios").textContent = data.usuarios;
        document.getElementById("stat-reservas").textContent = data.reservas;
        document.getElementById("stat-pendientes").textContent = data.pendientes;
      })
      .catch(function () {});
  }

  // ---------- RESERVAS ----------
  var reservasStatus = document.getElementById("reservas-status");
  var reservasTbody = document.getElementById("reservas-tbody");
  var MESAS = { pool: "Pool", carambola: "Carambola", snooker: "Snooker", vip: "VIP" };

  function cargarReservas() {
    reservasStatus.textContent = "Cargando reservas…";
    fetch(API + "/reservas", { headers: auth.authHeaders() })
      .then(function (res) {
        if (handleAuthError(res)) return null;
        return res.json();
      })
      .then(function (reservas) {
        if (!reservas) return;
        reservasStatus.textContent = reservas.length
          ? ""
          : "Todavía no hay reservas.";
        reservasTbody.innerHTML = "";
        reservas.forEach(function (r) {
          var tr = document.createElement("tr");
          tr.innerHTML =
            "<td>" + escapeHtml(r.nombre) + "</td>" +
            "<td>" + escapeHtml(r.telefono) + "</td>" +
            "<td>" + escapeHtml(r.fecha) + "</td>" +
            "<td>" + escapeHtml(r.hora) + "</td>" +
            "<td>" + (MESAS[r.mesa] || r.mesa) + "</td>" +
            "<td>" + r.personas + "</td>" +
            "<td></td>" +
            "<td></td>";

          var estadoTd = tr.children[6];
          var select = document.createElement("select");
          select.className = "row-select";
          ["pendiente", "confirmada", "cancelada"].forEach(function (est) {
            var opt = document.createElement("option");
            opt.value = est;
            opt.textContent = est.charAt(0).toUpperCase() + est.slice(1);
            if (est === r.estado) opt.selected = true;
            select.appendChild(opt);
          });
          select.addEventListener("change", function () {
            cambiarEstadoReserva(r._id, select.value);
          });
          estadoTd.appendChild(select);

          var accionesTd = tr.children[7];
          var btnDel = document.createElement("button");
          btnDel.className = "btn btn-danger btn-small";
          btnDel.type = "button";
          btnDel.textContent = "Eliminar";
          btnDel.addEventListener("click", function () {
            eliminarReserva(r._id);
          });
          accionesTd.appendChild(btnDel);

          reservasTbody.appendChild(tr);
        });
      })
      .catch(function () {
        reservasStatus.textContent = "No se pudieron cargar las reservas.";
        reservasStatus.style.color = "var(--ball-3)";
      });
  }

  function cambiarEstadoReserva(id, estado) {
    fetch(API + "/reservas/" + id, {
      method: "PATCH",
      headers: jsonHeaders(),
      body: JSON.stringify({ estado: estado }),
    })
      .then(function (res) {
        if (handleAuthError(res)) return;
        cargarResumen();
      })
      .catch(function () {});
  }

  function eliminarReserva(id) {
    if (!confirm("¿Eliminar esta reserva? Esta acción no se puede deshacer.")) return;
    fetch(API + "/reservas/" + id, { method: "DELETE", headers: auth.authHeaders() })
      .then(function (res) {
        if (handleAuthError(res)) return;
        cargarReservas();
        cargarResumen();
      })
      .catch(function () {});
  }

  // ---------- USUARIOS ----------
  var usuariosStatus = document.getElementById("usuarios-status");
  var usuariosTbody = document.getElementById("usuarios-tbody");

  function cargarUsuarios() {
    usuariosStatus.textContent = "Cargando usuarios…";
    fetch(API + "/admin/usuarios", { headers: auth.authHeaders() })
      .then(function (res) {
        if (handleAuthError(res)) return null;
        return res.json();
      })
      .then(function (usuarios) {
        if (!usuarios) return;
        usuariosStatus.textContent = usuarios.length ? "" : "No hay usuarios registrados todavía.";
        usuariosTbody.innerHTML = "";
        usuarios.forEach(function (u) {
          var tr = document.createElement("tr");
          var fecha = new Date(u.createdAt).toLocaleDateString("es-EC");
          tr.innerHTML =
            "<td>" + escapeHtml(u.nombre) +
            ' <span class="badge ' + (u.role === "admin" ? "badge-admin" : "badge-user") + '">' + u.role + "</span></td>" +
            "<td>" + escapeHtml(u.email) + "</td>" +
            "<td>" + escapeHtml(u.telefono || "—") + "</td>" +
            "<td>" + fecha + "</td>" +
            "<td></td>";

          var accionesTd = tr.children[4];
          if (u.role !== "admin") {
            var btnDel = document.createElement("button");
            btnDel.className = "btn btn-danger btn-small";
            btnDel.type = "button";
            btnDel.textContent = "Eliminar";
            btnDel.addEventListener("click", function () {
              eliminarUsuario(u._id);
            });
            accionesTd.appendChild(btnDel);
          }

          usuariosTbody.appendChild(tr);
        });
      })
      .catch(function () {
        usuariosStatus.textContent = "No se pudieron cargar los usuarios.";
        usuariosStatus.style.color = "var(--ball-3)";
      });
  }

  function eliminarUsuario(id) {
    if (!confirm("¿Eliminar este usuario registrado? Esta acción no se puede deshacer.")) return;
    fetch(API + "/admin/usuarios/" + id, { method: "DELETE", headers: auth.authHeaders() })
      .then(function (res) {
        if (handleAuthError(res)) return;
        cargarUsuarios();
        cargarResumen();
      })
      .catch(function () {});
  }

  // ---------- EVENTOS ----------
  var eventosStatus = document.getElementById("eventos-status");
  var eventosCards = document.getElementById("eventos-cards");
  var eventoForm = document.getElementById("evento-form");
  var btnNuevoEvento = document.getElementById("btn-nuevo-evento");
  var btnCancelarEvento = document.getElementById("btn-cancelar-evento");
  var TIPOS = {
    torneo: "Torneo", liga: "Liga", "noche-especial": "Noche especial",
    privado: "Evento privado", otro: "Otro",
  };

  function mostrarFormEvento(evento) {
    eventoForm.hidden = false;
    eventoForm.reset();
    eventoForm.elements.id.value = evento ? evento._id : "";
    if (evento) {
      eventoForm.elements.titulo.value = evento.titulo;
      eventoForm.elements.etiqueta.value = evento.etiqueta || "";
      eventoForm.elements.descripcion.value = evento.descripcion;
      eventoForm.elements.fecha.value = evento.fecha;
      eventoForm.elements.hora.value = evento.hora || "";
      eventoForm.elements.tipo.value = evento.tipo || "otro";
      eventoForm.elements.cupos.value = evento.cupos != null ? evento.cupos : "";
      eventoForm.elements.activo.checked = evento.activo !== false;
    } else {
      eventoForm.elements.activo.checked = true;
    }
    eventoForm.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  function ocultarFormEvento() {
    eventoForm.hidden = true;
    eventoForm.reset();
  }

  btnNuevoEvento.addEventListener("click", function () { mostrarFormEvento(null); });
  btnCancelarEvento.addEventListener("click", ocultarFormEvento);

  eventoForm.addEventListener("submit", function (e) {
    e.preventDefault();
    var fd = new FormData(eventoForm);
    var id = fd.get("id");
    var payload = {
      titulo: fd.get("titulo"),
      etiqueta: fd.get("etiqueta"),
      descripcion: fd.get("descripcion"),
      fecha: fd.get("fecha"),
      hora: fd.get("hora"),
      tipo: fd.get("tipo"),
      cupos: fd.get("cupos") ? Number(fd.get("cupos")) : undefined,
      activo: eventoForm.elements.activo.checked,
    };

    var url = id ? API + "/eventos/" + id : API + "/eventos";
    var method = id ? "PUT" : "POST";

    eventosStatus.textContent = "Guardando evento…";
    eventosStatus.style.color = "var(--brass-2)";

    fetch(url, { method: method, headers: jsonHeaders(), body: JSON.stringify(payload) })
      .then(function (res) {
        if (handleAuthError(res)) return null;
        return res.json().then(function (body) {
          if (!res.ok) throw new Error(body.error || "No se pudo guardar el evento.");
          return body;
        });
      })
      .then(function (body) {
        if (!body) return;
        eventosStatus.textContent = "Evento guardado.";
        eventosStatus.style.color = "var(--ball-6)";
        ocultarFormEvento();
        cargarEventos();
      })
      .catch(function (err) {
        eventosStatus.textContent = err.message;
        eventosStatus.style.color = "var(--ball-3)";
      });
  });

  function cargarEventos() {
    fetch(API + "/eventos?todos=1", { headers: auth.authHeaders() })
      .then(function (res) {
        if (handleAuthError(res)) return null;
        return res.json();
      })
      .then(function (eventos) {
        if (!eventos) return;
        eventosCards.innerHTML = "";
        if (!eventos.length) {
          eventosCards.innerHTML = '<p style="color:var(--ivory-dim)">No hay eventos creados todavía.</p>';
          return;
        }
        eventos.forEach(function (ev) {
          var card = document.createElement("div");
          card.className = "event-card";
          card.style.cursor = "default";
          card.innerHTML =
            '<span class="event-date">' + escapeHtml(ev.etiqueta || ev.fecha) + "</span>" +
            (ev.activo === false ? ' <span class="badge badge-cancelada">Oculto</span>' : "") +
            "<h3>" + escapeHtml(ev.titulo) + "</h3>" +
            "<p>" + escapeHtml(ev.descripcion) + "</p>" +
            '<p style="font-family:var(--mono);font-size:.78rem;color:var(--ivory-dim)">' +
              escapeHtml(ev.fecha) + (ev.hora ? " · " + escapeHtml(ev.hora) : "") + " · " + (TIPOS[ev.tipo] || ev.tipo) +
            "</p>";

          var actions = document.createElement("div");
          actions.className = "event-card-actions";

          var btnEdit = document.createElement("button");
          btnEdit.className = "btn btn-ghost btn-small";
          btnEdit.type = "button";
          btnEdit.textContent = "Editar";
          btnEdit.addEventListener("click", function () { mostrarFormEvento(ev); });

          var btnDel = document.createElement("button");
          btnDel.className = "btn btn-danger btn-small";
          btnDel.type = "button";
          btnDel.textContent = "Eliminar";
          btnDel.addEventListener("click", function () { eliminarEvento(ev._id); });

          actions.appendChild(btnEdit);
          actions.appendChild(btnDel);
          card.appendChild(actions);
          eventosCards.appendChild(card);
        });
      })
      .catch(function () {
        eventosStatus.textContent = "No se pudieron cargar los eventos.";
        eventosStatus.style.color = "var(--ball-3)";
      });
  }

  function eliminarEvento(id) {
    if (!confirm("¿Eliminar este evento?")) return;
    fetch(API + "/eventos/" + id, { method: "DELETE", headers: auth.authHeaders() })
      .then(function (res) {
        if (handleAuthError(res)) return;
        cargarEventos();
      })
      .catch(function () {});
  }

  // ---------- utilidades ----------
  function escapeHtml(str) {
    if (str == null) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  // ---------- init ----------
  cargarResumen();
  cargarReservas();
  cargarUsuarios();
  cargarEventos();
})();
