# Casa Carambola — sitio web de club de billar

Proyecto completo: frontend multi-página en HTML/CSS/JS puro (sin frameworks) + backend en Node/Express con **MongoDB**, que incluye reservas de mesa, **registro/login de usuarios** y un **panel de administración** para gestionar registros, reservas y eventos.

```
casa-carambola/
├── frontend/
│   ├── index.html          → inicio (mesa de billar animada)
│   ├── club.html            → sobre el club
│   ├── mesas.html           → mesas & tarifas
│   ├── torneos.html         → torneos & eventos (cargados desde la API)
│   ├── galeria.html         → galería
│   ├── reservar.html        → formulario de reserva
│   ├── login.html           → inicio de sesión
│   ├── registro.html        → creación de cuenta de usuario
│   ├── admin.html           → panel admin: registros, reservas y eventos
│   ├── css/
│   │   ├── variables.css    → paleta, tipografía, tokens
│   │   ├── base.css         → reset y estilos base
│   │   ├── layout.css       → topbar, secciones, footer
│   │   ├── components.css   → botones, tarjetas, tablas admin, auth, formularios
│   │   ├── animations.css   → clases de revelado al hacer scroll
│   │   └── home.css         → solo para index.html (mesa ilustrada)
│   └── js/
│       ├── nav.js           → menú móvil + enlace activo
│       ├── reveal.js        → animación de aparición al scroll
│       ├── sound.js         → sonido de "clac" de billar (Web Audio API)
│       ├── reservations.js  → envío del formulario de reserva al backend
│       ├── auth.js          → sesión compartida (token, menú de usuario en el nav)
│       ├── login.js         → formulario de inicio de sesión
│       ├── registro.js      → formulario de registro de usuario
│       ├── events.js        → carga los eventos publicados en torneos.html
│       └── admin.js         → lógica del panel admin (tabs, tablas, CRUD eventos)
├── backend/
│   ├── server.js
│   ├── package.json
│   ├── .env.example
│   ├── seed-admin.js        → crea/asciende el usuario administrador inicial
│   ├── models/
│   │   ├── Reservation.js
│   │   ├── User.js          → usuarios con rol "user" | "admin"
│   │   └── Event.js         → eventos/torneos gestionables desde el admin
│   ├── middleware/
│   │   └── auth.js          → verificación de JWT y de rol admin
│   └── routes/
│       ├── reservations.js  → crear reserva (público) + listar/editar/eliminar (admin)
│       ├── auth.js          → registro, login y perfil (/me)
│       ├── events.js        → listar eventos (público) + crear/editar/eliminar (admin)
│       └── admin.js         → listar/eliminar usuarios registrados + resumen
└── README.md
```

## 1. Requisitos

- Node.js 18+
- MongoDB corriendo localmente (`mongod`) **o** una base gratuita en [MongoDB Atlas](https://www.mongodb.com/atlas)

## 2. Instalar y correr el backend

```bash
cd backend
npm install
cp .env.example .env
# edita .env: MONGODB_URI (si usas Atlas), JWT_SECRET, y los datos de ADMIN_*
npm start
```

El servidor Express arranca en `http://localhost:3000` y **sirve el frontend directamente**: abre esa URL en el navegador para ver el sitio completo.

## 3. Crear el usuario administrador

El registro público (`registro.html`) **siempre crea cuentas con rol `user`** — por seguridad, un admin no se crea desde el navegador. Para crear el primer administrador, define `ADMIN_NOMBRE`, `ADMIN_EMAIL` y `ADMIN_PASSWORD` en tu `.env` y corre:

```bash
cd backend
npm run seed:admin
```

Esto crea (o asciende a admin) el usuario con ese correo. Luego inicia sesión en `login.html` con esas credenciales — te llevará directo a `admin.html`. Puedes volver a correr el script para crear más administradores cambiando esas variables antes de ejecutarlo.

## 4. Cuentas de usuario

- **Registro** (`registro.html`): cualquier visitante crea una cuenta (`nombre`, `email`, `teléfono` opcional, `password`).
- **Login** (`login.html`): devuelve un token JWT que se guarda en `localStorage` y se manda como `Authorization: Bearer <token>` en las llamadas protegidas.
- El menú de navegación (`#nav-auth`, controlado por `frontend/js/auth.js`) muestra "Ingresar" o, si hay sesión, el nombre del usuario / enlace al panel admin y "Salir".

## 5. Panel de administración (`admin.html`)

Solo accesible con una cuenta de rol `admin` (redirige a `login.html` si no hay sesión de admin). Tiene tres secciones:

- **Reservas**: tabla de todas las reservas, cambio de estado (pendiente/confirmada/cancelada) y **eliminar reserva**.
- **Registros de usuarios**: tabla de usuarios registrados (no admins) con opción de **eliminar** cuenta.
- **Eventos**: crear, editar y eliminar los eventos/torneos que se muestran públicamente en `torneos.html` (título, descripción, etiqueta corta, fecha, hora, tipo, cupos y visibilidad).

## 6. Endpoints de la API

| Método | Ruta                        | Acceso        | Qué hace                                   |
|--------|-----------------------------|---------------|----------------------------------------------|
| POST   | `/api/auth/registro`        | Público       | Crea una cuenta de usuario (rol `user`)      |
| POST   | `/api/auth/login`           | Público       | Inicia sesión, devuelve token + usuario      |
| GET    | `/api/auth/me`              | Autenticado   | Perfil del usuario del token                 |
| POST   | `/api/reservas`             | Público       | Crea una reserva nueva                       |
| GET    | `/api/reservas`             | Admin         | Lista todas las reservas                     |
| PATCH  | `/api/reservas/:id`         | Admin         | Cambia el estado de una reserva              |
| DELETE | `/api/reservas/:id`         | Admin         | Elimina una reserva                          |
| GET    | `/api/eventos`              | Público       | Lista eventos activos (`?todos=1` para admin)|
| POST   | `/api/eventos`              | Admin         | Crea un evento                               |
| PUT    | `/api/eventos/:id`          | Admin         | Edita un evento                              |
| DELETE | `/api/eventos/:id`          | Admin         | Elimina un evento                            |
| GET    | `/api/admin/usuarios`       | Admin         | Lista usuarios registrados                   |
| DELETE | `/api/admin/usuarios/:id`   | Admin         | Elimina un usuario registrado                |
| GET    | `/api/admin/resumen`        | Admin         | Conteos rápidos para el dashboard            |

Las rutas "Admin" requieren el header `Authorization: Bearer <token>` de una cuenta con `role: "admin"`.

## 7. El sonido de billar

`frontend/js/sound.js` genera el "clac" de las bolas **en tiempo real con la Web Audio API** — no hay archivos de audio que descargar ni mantener.

## 8. Personalizar

- Textos, precios y horarios: directo en cada archivo `.html` de `frontend/`.
- Colores y tipografías: variables CSS centralizadas en `frontend/css/variables.css`.
- Para producción, cambia `API_URL` en `frontend/js/reservations.js`, `frontend/js/auth.js` y `frontend/js/events.js` por la URL real de tu backend desplegado.
- Para agregar una página nueva, copia la estructura de `<head>` y del `<header>`/`<footer>` de cualquier página existente (incluyendo el `<span class="nav-auth" id="nav-auth">` y el script `js/auth.js`) para mantener la navegación y la sesión consistentes.
