const mongoose = require("mongoose");

const eventSchema = new mongoose.Schema(
  {
    titulo: { type: String, required: true, trim: true },
    descripcion: { type: String, required: true, trim: true },
    etiqueta: { type: String, trim: true }, // ej: "SÁB 25" (badge corto en la tarjeta)
    fecha: { type: String, required: true }, // formato YYYY-MM-DD
    hora: { type: String },
    tipo: {
      type: String,
      enum: ["torneo", "liga", "noche-especial", "privado", "otro"],
      default: "otro",
    },
    cupos: { type: Number, min: 0 },
    activo: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Event", eventSchema);
