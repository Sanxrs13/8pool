const mongoose = require("mongoose");

const reservationSchema = new mongoose.Schema(
  {
    nombre: { type: String, required: true, trim: true },
    telefono: { type: String, required: true, trim: true },
    fecha: { type: String, required: true }, // formato YYYY-MM-DD
    hora: { type: String, required: true },  // formato HH:MM
    mesa: {
      type: String,
      required: true,
      enum: ["pool", "carambola", "snooker", "vip"],
    },
    personas: { type: Number, min: 1, max: 8, default: 2 },
    estado: {
      type: String,
      enum: ["pendiente", "confirmada", "cancelada"],
      default: "pendiente",
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Reservation", reservationSchema);
