/**
 * Crea (o actualiza a rol admin) el usuario administrador definido en .env
 * Uso: node seed-admin.js
 */
require("dotenv").config();
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const User = require("./models/User");

const MONGODB_URI = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/casa_carambola";
const ADMIN_NOMBRE = process.env.ADMIN_NOMBRE || "Administrador";
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || "admin@casacarambola.ec").toLowerCase().trim();
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "CambiaEstaClave123";

async function run() {
  await mongoose.connect(MONGODB_URI);
  console.log("Conectado a MongoDB");

  const hash = await bcrypt.hash(ADMIN_PASSWORD, 10);
  const existente = await User.findOne({ email: ADMIN_EMAIL });

  if (existente) {
    existente.role = "admin";
    existente.password = hash;
    existente.nombre = ADMIN_NOMBRE;
    await existente.save();
    console.log(`Usuario existente actualizado a admin: ${ADMIN_EMAIL}`);
  } else {
    await User.create({
      nombre: ADMIN_NOMBRE,
      email: ADMIN_EMAIL,
      password: hash,
      role: "admin",
    });
    console.log(`Administrador creado: ${ADMIN_EMAIL}`);
  }

  console.log("Contraseña asignada:", ADMIN_PASSWORD, "(cámbiala luego de iniciar sesión)");
  await mongoose.disconnect();
  process.exit(0);
}

run().catch((err) => {
  console.error("Error al crear el administrador:", err.message);
  process.exit(1);
});
