const express = require("express");
const router = express.Router();
const Event = require("../models/Event");
const { requireAuth, requireAdmin } = require("../middleware/auth");

// GET /api/eventos -> lista pública de eventos activos (para torneos.html)
router.get("/", async (req, res) => {
  try {
    const soloActivos = req.query.todos !== "1";
    const filtro = soloActivos ? { activo: true } : {};
    const eventos = await Event.find(filtro).sort({ fecha: 1 });
    res.json(eventos);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "No se pudieron obtener los eventos." });
  }
});

// POST /api/eventos -> crear evento (solo admin)
router.post("/", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { titulo, descripcion, etiqueta, fecha, hora, tipo, cupos, activo } = req.body;

    if (!titulo || !descripcion || !fecha) {
      return res.status(400).json({ error: "Título, descripción y fecha son obligatorios." });
    }

    const evento = await Event.create({
      titulo,
      descripcion,
      etiqueta,
      fecha,
      hora,
      tipo,
      cupos,
      activo: activo !== undefined ? activo : true,
    });

    res.status(201).json(evento);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "No se pudo crear el evento." });
  }
});

// PUT /api/eventos/:id -> editar evento (solo admin)
router.put("/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { titulo, descripcion, etiqueta, fecha, hora, tipo, cupos, activo } = req.body;
    const evento = await Event.findByIdAndUpdate(
      req.params.id,
      { titulo, descripcion, etiqueta, fecha, hora, tipo, cupos, activo },
      { new: true, runValidators: true }
    );
    if (!evento) return res.status(404).json({ error: "Evento no encontrado." });
    res.json(evento);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "No se pudo actualizar el evento." });
  }
});

// DELETE /api/eventos/:id -> eliminar evento (solo admin)
router.delete("/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    const evento = await Event.findByIdAndDelete(req.params.id);
    if (!evento) return res.status(404).json({ error: "Evento no encontrado." });
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "No se pudo eliminar el evento." });
  }
});

module.exports = router;
