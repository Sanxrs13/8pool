const express = require("express");
const router = express.Router();
const Reservation = require("../models/Reservation");
const { requireAuth, requireAdmin } = require("../middleware/auth");

// POST /api/reservas -> crear una reserva nueva
router.post("/", async (req, res) => {
  try {
    const { nombre, telefono, fecha, hora, mesa, personas } = req.body;

    if (!nombre || !telefono || !fecha || !hora || !mesa) {
      return res.status(400).json({ error: "Faltan campos obligatorios." });
    }

    const reserva = await Reservation.create({
      nombre,
      telefono,
      fecha,
      hora,
      mesa,
      personas,
    });

    res.status(201).json(reserva);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "No se pudo guardar la reserva." });
  }
});

// GET /api/reservas -> listar reservas (solo administradores, vía panel admin)
router.get("/", requireAuth, requireAdmin, async (req, res) => {
  try {
    const reservas = await Reservation.find().sort({ fecha: 1, hora: 1 });
    res.json(reservas);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "No se pudieron obtener las reservas." });
  }
});

// PATCH /api/reservas/:id -> cambiar estado (confirmar / cancelar) (solo admin)
router.patch("/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { estado } = req.body;
    const reserva = await Reservation.findByIdAndUpdate(
      req.params.id,
      { estado },
      { new: true }
    );
    if (!reserva) return res.status(404).json({ error: "Reserva no encontrada." });
    res.json(reserva);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "No se pudo actualizar la reserva." });
  }
});

// DELETE /api/reservas/:id -> eliminar una reserva (solo admin)
router.delete("/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    const reserva = await Reservation.findByIdAndDelete(req.params.id);
    if (!reserva) return res.status(404).json({ error: "Reserva no encontrada." });
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "No se pudo eliminar la reserva." });
  }
});

module.exports = router;
