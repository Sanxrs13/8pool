const express = require("express");
const router = express.Router();
const User = require("../models/User");
const Reservation = require("../models/Reservation");
const { requireAuth, requireAdmin } = require("../middleware/auth");

// Todas las rutas de este archivo son solo para administradores
router.use(requireAuth, requireAdmin);

// GET /api/admin/usuarios -> listar usuarios registrados
router.get("/usuarios", async (req, res) => {
  try {
    const usuarios = await User.find().select("-password").sort({ createdAt: -1 });
    res.json(usuarios);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "No se pudieron obtener los usuarios." });
  }
});

// DELETE /api/admin/usuarios/:id -> eliminar un usuario registrado
router.delete("/usuarios/:id", async (req, res) => {
  try {
    if (req.params.id === req.user.id) {
      return res.status(400).json({ error: "No puedes eliminar tu propia cuenta de administrador." });
    }
    const usuario = await User.findByIdAndDelete(req.params.id);
    if (!usuario) return res.status(404).json({ error: "Usuario no encontrado." });
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "No se pudo eliminar el usuario." });
  }
});

// GET /api/admin/resumen -> conteos rápidos para el dashboard
router.get("/resumen", async (req, res) => {
  try {
    const [usuarios, reservas, pendientes] = await Promise.all([
      User.countDocuments({ role: "user" }),
      Reservation.countDocuments(),
      Reservation.countDocuments({ estado: "pendiente" }),
    ]);
    res.json({ usuarios, reservas, pendientes });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "No se pudo obtener el resumen." });
  }
});

module.exports = router;
