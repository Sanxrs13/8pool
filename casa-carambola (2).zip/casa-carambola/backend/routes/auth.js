const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const router = express.Router();
const User = require("../models/User");
const { requireAuth, JWT_SECRET } = require("../middleware/auth");

function signToken(user) {
  return jwt.sign(
    { id: user._id, nombre: user.nombre, email: user.email, role: user.role },
    JWT_SECRET,
    { expiresIn: "7d" }
  );
}

function publicUser(user) {
  return {
    id: user._id,
    nombre: user.nombre,
    email: user.email,
    telefono: user.telefono,
    role: user.role,
    createdAt: user.createdAt,
  };
}

// POST /api/auth/registro -> crear cuenta de usuario (siempre role "user")
router.post("/registro", async (req, res) => {
  try {
    const { nombre, email, telefono, password } = req.body;

    if (!nombre || !email || !password) {
      return res.status(400).json({ error: "Nombre, correo y contraseña son obligatorios." });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: "La contraseña debe tener al menos 6 caracteres." });
    }

    const existe = await User.findOne({ email: email.toLowerCase().trim() });
    if (existe) {
      return res.status(409).json({ error: "Ya existe una cuenta con ese correo." });
    }

    const hash = await bcrypt.hash(password, 10);
    const user = await User.create({
      nombre,
      email: email.toLowerCase().trim(),
      telefono,
      password: hash,
      role: "user",
    });

    const token = signToken(user);
    res.status(201).json({ token, user: publicUser(user) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "No se pudo crear la cuenta." });
  }
});

// POST /api/auth/login
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: "Correo y contraseña son obligatorios." });
    }

    const user = await User.findOne({ email: email.toLowerCase().trim() });
    if (!user) {
      return res.status(401).json({ error: "Correo o contraseña incorrectos." });
    }

    const ok = await bcrypt.compare(password, user.password);
    if (!ok) {
      return res.status(401).json({ error: "Correo o contraseña incorrectos." });
    }

    const token = signToken(user);
    res.json({ token, user: publicUser(user) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "No se pudo iniciar sesión." });
  }
});

// GET /api/auth/me -> perfil del usuario autenticado (sirve para validar el token guardado)
router.get("/me", requireAuth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ error: "Usuario no encontrado." });
    res.json({ user: publicUser(user) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "No se pudo obtener el perfil." });
  }
});

module.exports = router;
