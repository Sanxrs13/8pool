require("dotenv").config();
const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const path = require("path");

const reservationsRouter = require("./routes/reservations");
const authRouter = require("./routes/auth");
const eventsRouter = require("./routes/events");
const adminRouter = require("./routes/admin");

const app = express();
const PORT = process.env.PORT || 3000;
const MONGODB_URI = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/casa_carambola";

app.use(cors());
app.use(express.json());

// Sirve el frontend estático (../frontend) para no necesitar un servidor aparte
app.use(express.static(path.join(__dirname, "..", "frontend")));

// API
app.use("/api/reservas", reservationsRouter);
app.use("/api/auth", authRouter);
app.use("/api/eventos", eventsRouter);
app.use("/api/admin", adminRouter);

// Conexión a MongoDB
mongoose
  .connect(MONGODB_URI)
  .then(() => {
    console.log("Conectado a MongoDB");
    app.listen(PORT, () => {
      console.log(`Casa Carambola corriendo en http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error("Error al conectar con MongoDB:", err.message);
    process.exit(1);
  });
